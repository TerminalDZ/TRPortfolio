<?php
$host = "";
$user = "";
$password = "";
$userdb = "";
$base_url = "";
?>
