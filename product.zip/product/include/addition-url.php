<?php
// Common basic
$base_img_seo = BASEURL . 'upload/seo/';
$base_img_portfolio = BASEURL . 'upload/portfolio/';
$base_img_about = BASEURL . 'upload/about/';
$base_img_cv = BASEURL . 'upload/cv/';



// Common frontend theme one
$base_frontend_th_one_js = BASEURL . 'frontend/theme/one/assets/js/';
$base_frontend_th_one_css = BASEURL . 'frontend/theme/one/assets/css/';

// Common frontend theme two
$base_frontend_th_two_js = BASEURL . 'frontend/theme/two/assets/js/';
$base_frontend_th_two_css = BASEURL . 'frontend/theme/two/assets/css/';

// Common backend theme 
$base_backend = BASEURL . 'backend/';
$base_backend_js = BASEURL . 'backend/assets/js/';
$base_backend_css = BASEURL . 'backend/assets/css/';
$base_backend_assets = BASEURL . 'backend/assets/';
$base_backend_lib = BASEURL . 'backend/assets/libs/';
$base_backend_image = BASEURL . 'backend/assets/images/';




//Common DB

$base_db = BASEURL . 'include/check/';
