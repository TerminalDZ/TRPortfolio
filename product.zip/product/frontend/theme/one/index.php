<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>
<?php
include 'basic/head.php';
?>

</head>

<body id="top">
<?php
include 'basic/body.php';
?>
<?php
include 'basic/footer.php';
?>
</body>

</html>