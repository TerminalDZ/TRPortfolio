<!DOCTYPE html>
<html lang="en">
<head>
<?php
include 'basic/head.php';
?>

</head>
<body class="main-content">
<?php
include 'basic/body.php';
?>
<?php
include 'basic/footer.php';
?>
</body>
</html>