<meta charset="utf-8" />
        <title>Log In | <?= $seodata['title']?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?=$base_img_seo?><?= $seodata['icon']; ?>">

		<!-- Bootstrap css -->
		<link href="<?=$base_backend_css?>bootstrap.min.css" rel="stylesheet" type="text/css" />
		<!-- App css -->
		<link href="<?=$base_backend_css?>app.min.css" rel="stylesheet" type="text/css" id="app-style"/>
		<!-- icons -->
		<link href="<?=$base_backend_css?>icons.min.css" rel="stylesheet" type="text/css" />
		<!-- Head js -->
		<script src="<?=$base_backend_js?>head.js"></script>