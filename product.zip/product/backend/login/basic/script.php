

        <!-- Vendor js -->
        <script src="<?=$base_backend_js?>vendor.min.js"></script>

        <!-- App js -->
        <script src="<?=$base_backend_js?>app.min.js"></script>