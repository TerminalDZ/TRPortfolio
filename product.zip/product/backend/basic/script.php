 <!-- Vendor js -->
 <script src="<?=$base_backend_js?>vendor.min.js"></script>

<!-- Plugins js-->
<script src="<?=$base_backend_lib?>flatpickr/flatpickr.min.js"></script>
<script src="<?=$base_backend_lib?>apexcharts/apexcharts.min.js"></script>

<script src="<?=$base_backend_lib?>selectize/js/standalone/selectize.min.js"></script>

<!-- Dashboar 1 init js-->
<script src="<?=$base_backend_js?>pages/dashboard-1.init.js"></script>

<!-- App js-->
<script src="<?=$base_backend_js?>app.min.js"></script>
<!-- coustem -->
<script src="<?=$base_backend_js?>coustem.js"></script>

<!-- Tost-->
<script src="<?=$base_backend_lib?>jquery-toast-plugin/jquery.toast.min.js"></script>
<!-- toastr init js-->
<script src="<?=$base_backend_js?>pages/toastr.init.js"></script>

     <!-- third party js -->
     <script src="<?=$base_backend_lib?>datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-buttons/js/buttons.flash.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
        <script src="<?=$base_backend_lib?>datatables.net-select/js/dataTables.select.min.js"></script>
        <script src="<?=$base_backend_lib?>pdfmake/build/pdfmake.min.js"></script>
        <script src="<?=$base_backend_lib?>pdfmake/build/vfs_fonts.js"></script>
        <script src="<?=$base_backend_lib?>selectize/js/standalone/selectize.min.js"></script>
        <script src="<?=$base_backend_lib?>mohithg-switchery/switchery.min.js"></script>
        <script src="<?=$base_backend_lib?>multiselect/js/jquery.multi-select.js"></script>
        <script src="<?=$base_backend_lib?>select2/js/select2.min.js"></script>
        <script src="<?=$base_backend_lib?>jquery-mockjax/jquery.mockjax.min.js"></script>
        <script src="<?=$base_backend_lib?>devbridge-autocomplete/jquery.autocomplete.min.js"></script>
        <script src="<?=$base_backend_lib?>bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
        <script src="<?=$base_backend_lib?>bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <!-- third party js ends -->

        <!-- Datatables init -->
        <script src="<?=$base_backend_js?>pages/datatables.init.js"></script>
 <!-- Plugins js -->
 <script src="<?=$base_backend_lib?>dropzone/min/dropzone.min.js"></script>
        <script src="<?=$base_backend_lib?>dropify/js/dropify.min.js"></script>
        <script src="<?=$base_backend_js?>pages/form-fileuploads.init.js"></script>
        <script src="<?=$base_backend_lib?>parsleyjs/parsley.min.js"></script>
        <script src="<?=$base_backend_js?>pages/form-validation.init.js"></script>

        <!-- Init js-->
        <script src="<?=$base_backend_js?>pages/form-advanced.init.js"></script>

        <script src="<?=$base_backend_lib?>flatpickr/flatpickr.min.js"></script>
        <script src="<?=$base_backend_lib?>spectrum-colorpicker2/spectrum.min.js"></script>
        <script src="<?=$base_backend_lib?>clockpicker/bootstrap-clockpicker.min.js"></script>
        <script src="<?=$base_backend_lib?>bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

        <script src="<?=$base_backend_js?>pages/form-pickers.init.js"></script>
        <script src="<?=$base_backend_lib?>ion-rangeslider/js/ion.rangeSlider.min.js"></script>
        <script src="<?=$base_backend_js?>pages/range-sliders.init.js"></script>
        <script src="<?=$base_backend_lib?>twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
        <script src="<?=$base_backend_js?>pages/form-wizard.init.js"></script>