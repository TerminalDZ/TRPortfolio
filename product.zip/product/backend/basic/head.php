
        <meta charset="utf-8" />
        <title>Dashboard | <?= $seodata['title']?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?=$base_img_seo?><?= $seodata['icon']; ?>">

        <!-- Plugins css -->
        <link href="<?=$base_backend_lib?>flatpickr/flatpickr.min.css" rel="stylesheet" type="text/css" />
        <link href="<?=$base_backend_lib?>selectize/css/selectize.bootstrap3.css" rel="stylesheet" type="text/css" />
        
        <!-- Bootstrap css -->
        <link href="<?=$base_backend_css?>bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- App css -->
        <link href="<?=$base_backend_css?>app.min.css" rel="stylesheet" type="text/css" id="app-style"/>
        <!-- icons -->
        <link href="<?=$base_backend_css?>icons.min.css" rel="stylesheet" type="text/css" />
        <!-- Head js -->
        <script src="<?=$base_backend_js?>head.js"></script>
        <!-- Jquery Toast css -->
        <link href="<?=$base_backend_lib?>jquery-toast-plugin/jquery.toast.min.css" rel="stylesheet" type="text/css">
        <script src="https://kit.fontawesome.com/7b4a92adc3.js" crossorigin="anonymous"></script>
 <!-- third party css -->
 <link href="<?=$base_backend_lib?>datatables.net-bs5/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>datatables.net-select-bs5/css//select.bootstrap5.min.css" rel="stylesheet" type="text/css">
        <!-- third party css end -->
         <!-- Plugins css -->
         <link href="<?=$base_backend_lib?>mohithg-switchery/switchery.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>multiselect/css/multi-select.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>select2/css/select2.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>selectize/css/selectize.bootstrap3.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" type="text/css">
      


        <!-- Plugins css -->
        <link href="<?=$base_backend_lib?>dropzone/min/dropzone.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>dropify/css/dropify.min.css" rel="stylesheet" type="text/css">

        <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
<!-- Plugins css -->
<link href="<?=$base_backend_lib?>spectrum-colorpicker2/spectrum.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
        <link href="<?=$base_backend_lib?>ion-rangeslider/css/ion.rangeSlider.min.css" rel="stylesheet" type="text/css">
      
     
