<div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                  
                                    <h4 class="page-title">Settings</h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                          

                     <div class="col-lg-6 col-xl-6">
                               <a href="<?=$base_backend;?>?myacount" >  <div class="widget-rounded-circle card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="avatar-lg rounded-circle bg-soft-success">
                                                    <i class="fe-user font-22 avatar-title text-success"></i>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="text-end">
                                                    <h3 class="text-dark mt-3">My Account</h3>
                                                </div>
                                            </div>
                                        </div> <!-- end row-->
                                    </div>
                                </div></a> <!-- end widget-rounded-circle-->
                            </div> <!-- end col-->

                            <div class="col-lg-6 col-xl-6">
                               <a href="<?=$base_backend;?>?editusers" >  <div class="widget-rounded-circle card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="avatar-lg rounded-circle bg-soft-warning">
                                                    <i class="fe-users font-22 avatar-title text-warning"></i>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="text-end">
                                                    <h3 class="text-dark mt-3">Users Management</h3>
                                                </div>
                                            </div>
                                        </div> <!-- end row-->
                                    </div>
                                </div></a> <!-- end widget-rounded-circle-->
                            </div> <!-- end col-->

                            <div class="col-lg-6 col-xl-6">
                            <a href="<?=$base_backend;?>?editseo" >
                                <div class="widget-rounded-circle card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="avatar-lg rounded-circle bg-soft-primary">
                                                    <i class="fe-bar-chart-line- font-22 avatar-title text-primary"></i>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="text-end">
                                                    <h3 class="text-dark mt-3">SEO</h3>
                                                </div>
                                            </div>
                                        </div> <!-- end row-->
                                    </div>
                                </div> 
</a><!-- end widget-rounded-circle-->
                            </div> <!-- end col-->

                            <div class="col-lg-6 col-xl-6">
                            <a href="<?=$base_backend;?>?editsmtp" >
                                <div class="widget-rounded-circle card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="avatar-lg rounded-circle bg-soft-danger">
                                                    <i class="fe-mail font-22 avatar-title text-danger"></i>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="text-end">
                                                    <h3 class="text-dark mt-3">SMTP</h3>
                                                </div>
                                            </div>
                                        </div> <!-- end row-->
                                    </div>
</a>
                                </div> <!-- end widget-rounded-circle-->
                            </div> <!-- end col-->

                            <div class="col-lg-12 col-xl-12">
                               <a href="<?=$base_backend;?>?theme" >  <div class="widget-rounded-circle card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="avatar-lg rounded-circle bg-soft-secondary">
                                                    <i class="fe-eye font-22 avatar-title text-secondary"></i>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="text-end">
                                                    <h3 class="text-dark mt-3">Themes</h3>
                                                </div>
                                            </div>
                                        </div> <!-- end row-->
                                    </div>
                                </div></a> <!-- end widget-rounded-circle-->
                            </div> <!-- end col--> 

                        </div>