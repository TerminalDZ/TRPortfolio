<?php 
if (is_dir('install')) {
    header('Location: install/');
    exit;
  }
  
require 'include/init.php';
require 'include/visitor_log.php';
include 'frontend/theme/'.$seodata['theme'].'/index.php'
?>
