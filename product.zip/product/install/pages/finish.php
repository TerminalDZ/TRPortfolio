
  <form method="post" action="check.php" >

<div class="tab-pane active" id="basictab3" role="tabpanel">
   <div class="row">
      <div class="col-12">
         <div class="text-center">
            <h2 class="mt-0"><i class="mdi mdi-check-all"></i></h2>
            <h3 class="mt-0">Installed successfully !</h3>
            <div class="mb-3">
               <div class="form-check d-inline-block">
               <button type="submit" name="step04" class="btn btn-secondary">Finish</button>
                           </div>
            </div>
         </div>
      </div>
      <!-- end col -->
   </div>
   <!-- end row -->
</div>
</form>
